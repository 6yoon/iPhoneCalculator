import "../App.css";

function Line1({ result, setResult, mode, setMode, formula, setFormula }) {
  function handleResult(e) {
    if (result.length === 9) {
    } else {
      if (mode !== "") {
        const preResult = formula;
        setResult(`${e}`);
        if (mode === "+") setFormula(preResult + e);
        else if (mode === "-") setFormula(preResult - e);
        else if (mode === "×") setFormula(preResult * e);
        else if (mode === "÷") setFormula(preResult / e);
        setMode("");
      } else {
        if (result === "0") setResult(`${e}`);
        else setResult(`${result}${e}`);
        if (result.includes(".")) setFormula(Number(`${result}${e}`));
        else setFormula(e);
      }
    }
  }
  function setPlus() {
    setMode("+");
    formula === "" ? setResult("0") : setResult(`${formula}`);
  }
  return (
    <div className="line">
      <div className="round gray" onClick={() => handleResult(1)}>
        1
      </div>
      <div className="round gray" onClick={() => handleResult(2)}>
        2
      </div>
      <div className="round gray" onClick={() => handleResult(3)}>
        3
      </div>
      <div
        className={mode === "+" ? "round white" : "round orange"}
        onClick={setPlus}
      >
        +
      </div>
    </div>
  );
}

export default Line1;
