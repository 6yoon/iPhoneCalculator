import "../App.css";

function Line1({ result, setResult, mode, setMode, formula, setFormula }) {
  function resultClear() {
    setResult("0");
    setFormula("");
    setMode("");
  }
  function resultMinus() {
    if (result.length === 9) {
    } else {
      if (result.includes("-")) {
        setResult(`${-Number(result)}`);
        setFormula(-Number(result));
        console.log(-Number(result))
      } else {
        if(result === "0"){}
        else{
          setResult(`-${result}`);
          setFormula(-Number(result))
          console.log(-Number(result))
        }
      }
    }
  }
  function resultPercent() {
    setResult(`${Number(result) / 100.0}`);
    setFormula(Number(result) / 100.0);
  }
  function setDvide() {
    setMode("÷");
    formula === "" ? setResult("0") : setResult(formula);
  }
  return (
    <div className="line">
      <div className="round lightgray" onClick={resultClear}>
        {result === "0" ? "AC" : "C"}
      </div>
      <div className="round lightgray" onClick={resultMinus}>
        +/-
      </div>
      <div className="round lightgray" onClick={resultPercent}>
        %
      </div>
      <div
        className={mode === "÷" ? "round white" : "round orange"}
        onClick={setDvide}
      >
        ÷
      </div>
    </div>
  );
}

export default Line1;
