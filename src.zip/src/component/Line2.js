import "../App.css";

function Line1({ result, setResult, mode, setMode, formula, setFormula }) {
  function handleResult(e) {
    if (result.length === 9) {
    } else {
      if (mode !== "") {
        const preResult = formula;
        setResult(`${e}`);
        if (mode === "+") setFormula(preResult + e);
        else if (mode === "-") setFormula(preResult - e);
        else if (mode === "×") setFormula(preResult * e);
        else if (mode === "÷") setFormula(preResult / e);
        setMode("");
      } else {
        if (result === "0") setResult(`${e}`);
        else setResult(`${result}${e}`);
        if (result.includes(".")) setFormula(Number(`${result}${e}`));
        setFormula(e);
      }
    }
  }
  function setTimes() {
    setMode("×");
    formula === "" ? setResult("0") : setResult(`${formula}`);
  }
  return (
    <div className="line">
      <div className="round gray " onClick={() => handleResult(7)}>
        7
      </div>
      <div className="round gray" onClick={() => handleResult(8)}>
        8
      </div>
      <div className="round gray" onClick={() => handleResult(9)}>
        9
      </div>
      <div
        className={mode === "×" ? "round white" : "round orange"}
        onClick={setTimes}
      >
        ×
      </div>
    </div>
  );
}

export default Line1;
