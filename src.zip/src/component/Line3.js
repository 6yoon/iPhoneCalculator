import "../App.css";

function Line1({ result, setResult, mode, setMode, formula, setFormula }) {
  function handleResult(e) {
    if (result.length === 9) {
    } else {
      if (mode !== "") {
        const preResult = formula;
        setResult(`${e}`);
        if (mode === "+") setFormula(preResult + e);
        else if (mode === "-") setFormula(preResult - e);
        else if (mode === "×") setFormula(preResult * e);
        else if (mode === "÷") setFormula(preResult / e);
        setMode("");
      } else {
        if (result === "0") setResult(`${e}`);
        else setResult(`${result}${e}`);
        if (result.includes(".")) setFormula(Number(`${result}${e}`));
        else setFormula(e);
      }
    }
  }
  function setMinus() {
    setMode("-");
    formula === "" ? setResult("0") : setResult(`${formula}`);
  }
  return (
    <div className="line">
      <div className="round gray" onClick={() => handleResult(4)}>
        4
      </div>
      <div className="round gray" onClick={() => handleResult(5)}>
        5
      </div>
      <div className="round gray" onClick={() => handleResult(6)}>
        6
      </div>
      <div
        className={mode === "-" ? "round white" : "round orange"}
        onClick={setMinus}
      >
        -
      </div>
    </div>
  );
}

export default Line1;
