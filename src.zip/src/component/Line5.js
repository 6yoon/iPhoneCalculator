import "../App.css";

function Line1({ result, setResult, mode, setMode, formula, setFormula }) {
  function handleResult(e) {
    if (result.length === 9) {
    } else {
      if (mode !== "") {
        const preResult = formula;
        setResult(`${e}`);
        if (mode === "+")
          setFormula(preResult + e);
        else if (mode === "-")
          setFormula(preResult - e);
        else if (mode === "×")
          setFormula(preResult * e);  
        else if (mode === "÷")
          setFormula(preResult / e);
        setMode("");  
      } else {
        if (result === "0") setResult(`${e}`);
        else setResult(`${result}${e}`);
        if(result.includes(".")) setFormula(Number(`${result}${e}`));
        else setFormula(e);
      }
    }
  }
  function primeNumber() {
    if (result.includes(".")) {
    } else setResult(`${result}.`);
  }

  return (
    <div className="line">
      <div className="round0 gray" onClick={() => handleResult(0)}>
        0
      </div>
      <div className="round gray" onClick={primeNumber}>
        .
      </div>
      <div className={"round orange"} onClick={()=>setResult(formula)}>=</div>
    </div>
  );
}

export default Line1;
