import "./App.css";
import Line1 from "./component/Line1";
import Line2 from "./component/Line2";
import Line3 from "./component/Line3";
import Line4 from "./component/Line4";
import Line5 from "./component/Line5";
import { useState } from "react";

function App() {
  const [result, setResult] = useState("0");
  const [mode, setMode] = useState("");
  const [formula, setFormula] = useState("");
  return (
    <div className="App">
      <div className="calc">
        <h1>iPhone Calculator</h1>
        <div className="calcBackground">
          <div className="clacBox">
            <div className="resultBox">
              <div className={`${Number(result)}`.length < 7 ? "result" : "result2"}>
                {result}
              </div>
            </div>
            <div className="buttonBox">
              <Line1
                result={result}
                setResult={setResult}
                mode={mode}
                setMode={setMode}
                formula={formula}
                setFormula={setFormula}
              ></Line1>
              <Line2
                result={result}
                setResult={setResult}
                mode={mode}
                setMode={setMode}
                formula={formula}
                setFormula={setFormula}
              ></Line2>
              <Line3
                result={result}
                setResult={setResult}
                mode={mode}
                setMode={setMode}
                formula={formula}
                setFormula={setFormula}
              ></Line3>
              <Line4
                result={result}
                setResult={setResult}
                mode={mode}
                setMode={setMode}
                formula={formula}
                setFormula={setFormula}
              ></Line4>
              <Line5
                result={result}
                setResult={setResult}
                mode={mode}
                setMode={setMode}
                formula={formula}
                setFormula={setFormula}
              ></Line5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
